import boto3
import os
import json
from face_recognition_code import face_recognition_function 


s3_client = boto3.client('s3')

def lambda_handler(event, context):
    try:
        print("Received event:", json.dumps(event, indent=2))
        
        bucket_name = event['bucket_name']
        image_file_name = event['image_file_name']
        print(f"Processing image from bucket: {bucket_name}, key: {image_file_name}")
        
        image_path = f"/tmp/{os.path.basename(image_file_name)}"
        s3_client.download_file(bucket_name, image_file_name, image_path)
        print(f"Downloaded image to {image_path}")
        data_path = "/var/task/data.pt"
        recognized_name = face_recognition_function(image_path)
        if recognized_name is None:
            print(f"No face recognized in {image_file_name}.")
            return {
                'statusCode': 200,
                'body': json.dumps('No face detected.')
            }
        print(f"Recognized name: {recognized_name}")

        output_file_name = os.path.splitext(os.path.basename(image_file_name))[0] + ".txt"
        output_path = f"/tmp/{output_file_name}"
        with open(output_path, "w") as f:
            f.write(recognized_name)
        print(f"Saved recognized name to {output_path}")
        output_bucket = os.environ.get("OUTPUT_BUCKET")  # Set this environment variable
        s3_client.upload_file(output_path, output_bucket, output_file_name)
        print(f"Uploaded {output_file_name} to bucket: {output_bucket}")

        return {
            'statusCode': 200,
            'body': json.dumps(f"Recognized name '{recognized_name}' saved to {output_file_name}")
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': 'An error occurred',
                'error': str(e)
            })
        }